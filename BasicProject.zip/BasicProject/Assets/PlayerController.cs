﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    private void OnCollisionEnter(Collision col) {
        Debug.Log("col:" + col.gameObject.tag);
        if (col.gameObject.tag == "Enemy")
        {
            Time.timeScale = 0.5f;
            while (!Input.GetKeyDown("p")) ;
            Time.timeScale = 1;
        }
    }
}
