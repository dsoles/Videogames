﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChaseTarget : MonoBehaviour {

    Transform Target;
    public int MoveSpeed = 4;
    //int MaxDist = 10;
    public int ChaseDistance = 100;

    void Start()
    {
        Target = GameObject.FindWithTag("Player").transform;
    }

    void Update()
    {
        transform.LookAt(Target);
        transform.position += transform.forward * MoveSpeed * Time.deltaTime;
    }

    
}
